<# : batch portion
@echo off
setlocal enabledelayedexpansion

REM Hybrid PowerShell/Batch WCP Extractor
REM Usage:
REM   WCPExtractor.bat -file input.manifest output.xml [wcp.dll]
REM   WCPExtractor.bat -folder C:\InputFolder C:\OutputFolder [wcp.dll]

set "mode="
set "arg1="
set "arg2="
set "arg3="

if /i "%~1"=="-file" (
    set "mode=file"
    if not "%~2"=="" set "arg1=%~2"
    if not "%~3"=="" set "arg2=%~3"
    if not "%~4"=="" set "arg3=%~4"
) else if /i "%~1"=="-folder" (
    set "mode=folder"
    if not "%~2"=="" set "arg1=%~2"
    if not "%~3"=="" set "arg2=%~3"
    if not "%~4"=="" set "arg3=%~4"
) else (
    echo Usage:
    echo   %~nx0 -file input.manifest output.xml [wcp.dll]
    echo   %~nx0 -folder C:\InputFolder C:\OutputFolder [wcp.dll]
    exit /b 1
)

if "%mode%"=="file" (
    if "%arg1%"=="" (
        echo Error: Input file required
        exit /b 1
    )
    if "%arg2%"=="" (
        echo Error: Output file required
        exit /b 1
    )
    if "%arg3%"=="" (
        powershell -ExecutionPolicy Bypass -NoProfile -Command "$script=[System.IO.File]::ReadAllText('%~f0'); Invoke-Expression $script; Expand-WCPFile -InputFile '%arg1%' -OutputFile '%arg2%'"
    ) else (
        powershell -ExecutionPolicy Bypass -NoProfile -Command "$script=[System.IO.File]::ReadAllText('%~f0'); Invoke-Expression $script; Expand-WCPFile -InputFile '%arg1%' -OutputFile '%arg2%' -WCPDllPath '%arg3%'"
    )
) else if "%mode%"=="folder" (
    if "%arg1%"=="" (
        echo Error: Input folder required
        exit /b 1
    )
    if "%arg2%"=="" (
        echo Error: Output folder required
        exit /b 1
    )
    if "%arg3%"=="" (
        powershell -ExecutionPolicy Bypass -NoProfile -Command "$script=[System.IO.File]::ReadAllText('%~f0'); Invoke-Expression $script; Expand-WCPFolder -InputFolder '%arg1%' -OutputFolder '%arg2%'"
    ) else (
        powershell -ExecutionPolicy Bypass -NoProfile -Command "$script=[System.IO.File]::ReadAllText('%~f0'); Invoke-Expression $script; Expand-WCPFolder -InputFolder '%arg1%' -OutputFolder '%arg2%' -WCPDllPath '%arg3%'"
    )
)

exit /b %errorlevel%

: end batch / begin PowerShell hybrid chimera #>

# WCPExtractor - Hybrid PowerShell/Batch Script
# Based on wcpex.c by Smx

Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;

namespace WCP {
    [StructLayout(LayoutKind.Sequential)]
    public struct BlobData {
        public IntPtr length;
        public IntPtr fill;
        public IntPtr pData;
    }

    public static class NativeMethods {
        [DllImport("kernel32.dll", SetLastError = true)]
        public static extern IntPtr LoadLibrary(string dllToLoad);

        [DllImport("kernel32.dll", SetLastError = true)]
        public static extern IntPtr GetProcAddress(IntPtr hModule, string procedureName);

        [DllImport("kernel32.dll", SetLastError = true)]
        public static extern bool FreeLibrary(IntPtr hModule);
    }

    public delegate uint GetCompressedFileTypeDelegate(ref BlobData arg);
    public delegate int InitializeDeltaCompressorDelegate(IntPtr arg);
    public delegate int DeltaDecompressBufferDelegate(
        uint DeltaFlagType, IntPtr pDictionary, uint headerSize,
        ref BlobData inData, ref BlobData outData);
    public delegate int LoadFirstResourceLanguageAgnosticDelegate(
        uint unused, IntPtr hModule, ushort lpType, ushort lpName, IntPtr pOutDict);
}
'@

function Get-ProcessorArchitecture {
    $arch = $env:PROCESSOR_ARCHITECTURE
    $archW6432 = $env:PROCESSOR_ARCHITEW6432
    
    if ($arch -eq "ARM64" -or $archW6432 -eq "ARM64") { return "arm64" }
    elseif ($arch -eq "AMD64" -or $archW6432 -eq "AMD64") { return "x64" }
    else { return "x86" }
}

function Find-LatestWCPDll {
    $architecture = Get-ProcessorArchitecture
    $bitnessText = switch ($architecture) {
        "x64" { "64-bit (x64)" }
        "arm64" { "64-bit (ARM64)" }
        "x86" { "32-bit (x86)" }
    }
    
    Write-Host "Searching for $bitnessText wcp.dll..." -ForegroundColor Cyan
    
    $searchPaths = @()
    $searchPaths += Join-Path $env:WINDIR "System32\wcp.dll"
    
    switch ($architecture) {
        "x64" { $searchPaths += Join-Path $env:WINDIR "WinSxS\amd64_microsoft-windows-servicingstack*\wcp.dll" }
        "arm64" { $searchPaths += Join-Path $env:WINDIR "WinSxS\arm64_microsoft-windows-servicingstack*\wcp.dll" }
        "x86" { $searchPaths += Join-Path $env:WINDIR "WinSxS\x86_microsoft-windows-servicingstack*\wcp.dll" }
    }
    
    $wcpFiles = @()
    foreach ($path in $searchPaths) {
        $found = Get-ChildItem -Path $path -ErrorAction SilentlyContinue
        if ($found) {
            foreach ($file in $found) {
                try {
                    $bytes = [System.IO.File]::ReadAllBytes($file.FullName)
                    if ($bytes.Length -gt 0x3C) {
                        $peOffset = [BitConverter]::ToInt32($bytes, 0x3C)
                        if ($bytes.Length -gt $peOffset + 4 + 20) {
                            $machine = [BitConverter]::ToUInt16($bytes, $peOffset + 4)
                            $isCorrectArch = $false
                            
                            switch ($architecture) {
                                "x64" { if ($machine -eq 0x8664 -or $machine -eq 0x0200) { $isCorrectArch = $true } }
                                "arm64" { if ($machine -eq 0xAA64) { $isCorrectArch = $true } }
                                "x86" { if ($machine -eq 0x014c) { $isCorrectArch = $true } }
                            }
                            
                            if ($isCorrectArch) { $wcpFiles += $file }
                        }
                    }
                } catch {
                    if ($file.DirectoryName -eq (Join-Path $env:WINDIR "System32")) {
                        $wcpFiles += $file
                    }
                }
            }
        }
    }
    
    if ($wcpFiles.Count -eq 0) {
        throw "$bitnessText wcp.dll not found"
    }
    
    $latestWcp = $wcpFiles | ForEach-Object {
        $fileInfo = $_
        $versionInfo = [System.Diagnostics.FileVersionInfo]::GetVersionInfo($fileInfo.FullName)
        [PSCustomObject]@{
            Path = $fileInfo.FullName
            FileVersion = $versionInfo.FileVersion
            VersionObject = [Version]::new($versionInfo.FileMajorPart, $versionInfo.FileMinorPart, 
                                          $versionInfo.FileBuildPart, $versionInfo.FilePrivatePart)
        }
    } | Sort-Object -Property VersionObject -Descending | Select-Object -First 1
    
    Write-Host "Found: $($latestWcp.Path) (v$($latestWcp.FileVersion))" -ForegroundColor Green
    return $latestWcp.Path
}

function Initialize-WCPModule {
    param([Parameter(Mandatory=$true)][string]$WCPPath)
    
    $wcpModule = [WCP.NativeMethods]::LoadLibrary($WCPPath)
    if ($wcpModule -eq [IntPtr]::Zero) {
        throw "Failed to load wcp.dll from '$WCPPath'"
    }
    
    $functions = @{ Module = $wcpModule; DllPath = $WCPPath }
    
    $procAddresses = @{
        GetCompressedFileType = "?GetCompressedFileType@Rtl@WCP@Windows@@YAKPEBU_LBLOB@@@Z"
        InitializeDeltaCompressor = "?InitializeDeltaCompressor@Rtl@Windows@@YAJPEAX@Z"
        DeltaDecompressBuffer = "?DeltaDecompressBuffer@Rtl@Windows@@YAJKPEAU_LBLOB@@_K0PEAVAutoDeltaBlob@12@@Z"
        LoadFirstResourceLanguageAgnostic = "?LoadFirstResourceLanguageAgnostic@Rtl@Windows@@YAJKPEAUHINSTANCE__@@PEBG1PEAU_LBLOB@@@Z"
    }
    
    foreach ($func in $procAddresses.GetEnumerator()) {
        $ptr = [WCP.NativeMethods]::GetProcAddress($wcpModule, $func.Value)
        if ($ptr -eq [IntPtr]::Zero) {
            [WCP.NativeMethods]::FreeLibrary($wcpModule) | Out-Null
            throw "Failed to get procedure address for $($func.Key)"
        }
        
        switch ($func.Key) {
            "GetCompressedFileType" {
                $functions[$func.Key] = [System.Runtime.InteropServices.Marshal]::GetDelegateForFunctionPointer(
                    $ptr, [WCP.GetCompressedFileTypeDelegate])
            }
            "InitializeDeltaCompressor" {
                $functions[$func.Key] = [System.Runtime.InteropServices.Marshal]::GetDelegateForFunctionPointer(
                    $ptr, [WCP.InitializeDeltaCompressorDelegate])
            }
            "DeltaDecompressBuffer" {
                $functions[$func.Key] = [System.Runtime.InteropServices.Marshal]::GetDelegateForFunctionPointer(
                    $ptr, [WCP.DeltaDecompressBufferDelegate])
            }
            "LoadFirstResourceLanguageAgnostic" {
                $functions[$func.Key] = [System.Runtime.InteropServices.Marshal]::GetDelegateForFunctionPointer(
                    $ptr, [WCP.LoadFirstResourceLanguageAgnosticDelegate])
            }
        }
    }
    
    return $functions
}

function Expand-WCPFileInternal {
    param(
        [Parameter(Mandatory=$true)][string]$InputFile,
        [Parameter(Mandatory=$false)][string]$OutputFile,
        [Parameter(Mandatory=$true)][hashtable]$WCPModule,
        [Parameter(Mandatory=$false)][switch]$Quiet
    )
    
    if (-not (Test-Path $InputFile)) {
        throw "Input file not found: $InputFile"
    }
    
    $InputFile = [System.IO.Path]::GetFullPath($InputFile)
    $inputDataPtr = [IntPtr]::Zero
    $dictDataPtr = [IntPtr]::Zero
    
    try {
        if (-not $Quiet) {
            Write-Host "Reading: $([System.IO.Path]::GetFileName($InputFile))" -ForegroundColor Yellow
        }
        
        $fileBytes = [System.IO.File]::ReadAllBytes($InputFile)
        $fileSize = $fileBytes.Length
        
        if (-not $Quiet) {
            Write-Host "Input size: $fileSize bytes" -ForegroundColor Gray
        }
        
        if ($fileSize -eq 0) { throw "Input file is empty" }
        
        $inputDataPtr = [System.Runtime.InteropServices.Marshal]::AllocHGlobal($fileSize)
        [System.Runtime.InteropServices.Marshal]::Copy($fileBytes, 0, $inputDataPtr, $fileSize)
        
        $inData = New-Object WCP.BlobData
        $inData.length = [IntPtr]$fileSize
        $inData.fill = [IntPtr]$fileSize
        $inData.pData = $inputDataPtr
        
        $fileType = $WCPModule.GetCompressedFileType.Invoke([ref]$inData)
        if (-not $Quiet) {
            Write-Host "Compression type: $fileType" -ForegroundColor Gray
        }
        
        $result = $WCPModule.InitializeDeltaCompressor.Invoke([IntPtr]::Zero)
        if (-not $Quiet) {
            Write-Host "InitializeDeltaCompressor: 0x$($result.ToString('X8'))" -ForegroundColor Gray
        }
        if ($result -lt 0) { throw "InitializeDeltaCompressor failed: 0x$($result.ToString('X8'))" }
        
        $dictDataPtr = [System.Runtime.InteropServices.Marshal]::AllocHGlobal(24)
        
        $result = $WCPModule.LoadFirstResourceLanguageAgnostic.Invoke(0, $WCPModule.Module, 0x266, 1, $dictDataPtr)
        if (-not $Quiet) {
            Write-Host "LoadFirstResourceLanguageAgnostic: 0x$($result.ToString('X8'))" -ForegroundColor Gray
        }
        if ($result -lt 0) { throw "LoadFirstResourceLanguageAgnostic failed: 0x$($result.ToString('X8'))" }
        
        $outData = New-Object WCP.BlobData
        
        if (-not $Quiet) {
            Write-Host "Decompressing..." -ForegroundColor Yellow
        }
        $result = $WCPModule.DeltaDecompressBuffer.Invoke(2, $dictDataPtr, 4, [ref]$inData, [ref]$outData)
        if (-not $Quiet) {
            Write-Host "DeltaDecompressBuffer: 0x$($result.ToString('X8'))" -ForegroundColor Gray
        }
        if ($result -lt 0) { throw "DeltaDecompressBuffer failed: 0x$($result.ToString('X8'))" }
        
        $outputSize = [int]$outData.length
        if (-not $Quiet) {
            Write-Host "Output size: $outputSize bytes" -ForegroundColor Gray
        }
        if ($outputSize -eq 0) { throw "Decompression resulted in empty output" }
        
        $outputBytes = New-Object byte[] $outputSize
        [System.Runtime.InteropServices.Marshal]::Copy($outData.pData, $outputBytes, 0, $outputSize)
        $outputText = [System.Text.Encoding]::UTF8.GetString($outputBytes)
        
        if ($OutputFile) {
            $OutputFile = [System.IO.Path]::GetFullPath($OutputFile)
            $outputDir = Split-Path -Parent $OutputFile
            if ($outputDir -and -not (Test-Path $outputDir)) {
                New-Item -ItemType Directory -Path $outputDir -Force | Out-Null
            }
            [System.IO.File]::WriteAllText($OutputFile, $outputText, [System.Text.Encoding]::UTF8)
            if (-not $Quiet) {
                Write-Host "`n=== SUCCESS ===" -ForegroundColor Green
                Write-Host "Decompressed to: $OutputFile" -ForegroundColor Green
                Write-Host "Ratio: $fileSize bytes -> $outputSize bytes ($([math]::Round(($outputSize/$fileSize)*100, 2))%)" -ForegroundColor Green
            }
        } else {
            Write-Output $outputText
        }
    } finally {
        if ($inputDataPtr -ne [IntPtr]::Zero) {
            [System.Runtime.InteropServices.Marshal]::FreeHGlobal($inputDataPtr)
        }
        if ($dictDataPtr -ne [IntPtr]::Zero) {
            [System.Runtime.InteropServices.Marshal]::FreeHGlobal($dictDataPtr)
        }
    }
}

function Expand-WCPFile {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)][string]$InputFile,
        [Parameter(Mandatory=$false)][string]$OutputFile,
        [Parameter(Mandatory=$false)][string]$WCPDllPath
    )
    
    $wcp = $null
    
    try {
        if ([string]::IsNullOrEmpty($WCPDllPath)) {
            $WCPDllPath = Find-LatestWCPDll
        } else {
            Write-Host "Using specified wcp.dll: $WCPDllPath" -ForegroundColor Cyan
        }
        
        Write-Host "`nInitializing WCP module..." -ForegroundColor Yellow
        $wcp = Initialize-WCPModule -WCPPath $WCPDllPath
        
        Expand-WCPFileInternal -InputFile $InputFile -OutputFile $OutputFile -WCPModule $wcp
        
    } catch {
        Write-Host "`n=== ERROR ===" -ForegroundColor Red
        Write-Host $_.Exception.Message -ForegroundColor Red
        throw
    } finally {
        if ($wcp -and $wcp.Module -ne [IntPtr]::Zero) {
            [WCP.NativeMethods]::FreeLibrary($wcp.Module) | Out-Null
        }
    }
}

function Expand-WCPFolder {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)][string]$InputFolder,
        [Parameter(Mandatory=$true)][string]$OutputFolder,
        [Parameter(Mandatory=$false)][string]$WCPDllPath
    )
    
    if (-not (Test-Path $InputFolder)) {
        throw "Input folder not found: $InputFolder"
    }
    
    if (-not (Test-Path $OutputFolder)) {
        New-Item -ItemType Directory -Path $OutputFolder -Force | Out-Null
    }
    
    $manifests = Get-ChildItem -Path $InputFolder -Filter "*.manifest" -File
    
    if ($manifests.Count -eq 0) {
        Write-Host "No .manifest files found in $InputFolder" -ForegroundColor Yellow
        return
    }
    
    Write-Host "`nFound $($manifests.Count) manifest file(s)" -ForegroundColor Cyan
    Write-Host "Input folder: $InputFolder" -ForegroundColor Gray
    Write-Host "Output folder: $OutputFolder" -ForegroundColor Gray
    
    # Find and initialize WCP DLL once for all files
    $wcp = $null
    try {
        if ([string]::IsNullOrEmpty($WCPDllPath)) {
            Write-Host ""
            $WCPDllPath = Find-LatestWCPDll
        } else {
            Write-Host "`nUsing specified wcp.dll: $WCPDllPath" -ForegroundColor Cyan
        }
        
        Write-Host "`nInitializing WCP module (will be reused for all files)..." -ForegroundColor Yellow
        $wcp = Initialize-WCPModule -WCPPath $WCPDllPath
        Write-Host "WCP module initialized successfully`n" -ForegroundColor Green
        
        $successCount = 0
        $failCount = 0
        $startTime = Get-Date
        
        foreach ($manifest in $manifests) {
            $outputFileName = [System.IO.Path]::GetFileNameWithoutExtension($manifest.Name) + ".xml"
            $outputPath = Join-Path $OutputFolder $outputFileName
            
            $currentNum = $successCount + $failCount + 1
            Write-Host "[$currentNum/$($manifests.Count)] $($manifest.Name)" -ForegroundColor Cyan -NoNewline
            
            try {
                Expand-WCPFileInternal -InputFile $manifest.FullName -OutputFile $outputPath -WCPModule $wcp -Quiet
                Write-Host " -> OK" -ForegroundColor Green
                $successCount++
            } catch {
                Write-Host " -> FAILED: $($_.Exception.Message)" -ForegroundColor Red
                $failCount++
            }
        }
        
        $endTime = Get-Date
        $elapsed = $endTime - $startTime
        
        Write-Host "`n=== Batch processing complete ===" -ForegroundColor Cyan
        Write-Host "Successful: $successCount" -ForegroundColor Green
        Write-Host "Failed: $failCount" -ForegroundColor $(if ($failCount -gt 0) { "Red" } else { "Gray" })
        Write-Host "Total: $($manifests.Count)" -ForegroundColor Gray
        Write-Host "Time elapsed: $($elapsed.ToString('mm\:ss\.fff'))" -ForegroundColor Gray
        
    } finally {
        if ($wcp -and $wcp.Module -ne [IntPtr]::Zero) {
            Write-Host "`nCleaning up WCP module..." -ForegroundColor Gray
            [WCP.NativeMethods]::FreeLibrary($wcp.Module) | Out-Null
        }
    }
}

function Test-WCPManifest {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$false)][string]$ManifestName,
        [Parameter(Mandatory=$false)][string]$OutputPath = $env:TEMP
    )
    
    try {
        $manifestsPath = Join-Path $env:WINDIR "WinSxS\Manifests"
        if (-not (Test-Path $manifestsPath)) {
            throw "Manifests directory not found: $manifestsPath"
        }
        
        Write-Host "`n=== Testing WCP Decompression ===" -ForegroundColor Cyan
        Write-Host "Manifests directory: $manifestsPath" -ForegroundColor Gray
        
        if ($ManifestName) {
            $manifestFile = Get-ChildItem -Path $manifestsPath -Filter $ManifestName -ErrorAction SilentlyContinue | Select-Object -First 1
            if (-not $manifestFile) {
                throw "Specified manifest not found: $ManifestName"
            }
        } else {
            $manifestFile = Get-ChildItem -Path $manifestsPath -Filter "*.manifest" | Select-Object -First 1
            if (-not $manifestFile) {
                throw "No manifest files found"
            }
        }
        
        Write-Host "`nSelected manifest:" -ForegroundColor Yellow
        Write-Host "  Name: $($manifestFile.Name)" -ForegroundColor White
        Write-Host "  Size: $($manifestFile.Length) bytes" -ForegroundColor White
        
        $outputFileName = [System.IO.Path]::GetFileNameWithoutExtension($manifestFile.Name) + "_decompressed.xml"
        $outputFilePath = Join-Path $OutputPath $outputFileName
        
        Expand-WCPFile -InputFile $manifestFile.FullName -OutputFile $outputFilePath
        
        if (Test-Path $outputFilePath) {
            Write-Host "`n=== Preview ===" -ForegroundColor Cyan
            $content = Get-Content $outputFilePath -TotalCount 5
            $content | ForEach-Object { Write-Host "  $_" -ForegroundColor Gray }
            
            try {
                [xml]$xmlContent = Get-Content $outputFilePath -Raw
                Write-Host "`nXML Validation: PASSED" -ForegroundColor Green
                Write-Host "Root element: <$($xmlContent.DocumentElement.Name)>" -ForegroundColor Gray
            } catch {
                Write-Host "`nXML Validation: FAILED - $_" -ForegroundColor Red
            }
        }
    } catch {
        Write-Host "`n=== ERROR ===" -ForegroundColor Red
        Write-Host $_.Exception.Message -ForegroundColor Red
    }
}