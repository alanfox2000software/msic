@setlocal DisableDelayedExpansion
@ECHO OFF

SET "_MOUNT=C:\Mount"
SET "_File=kernel32.dll"

SET "_MOUNT="
SET "_File="

set "_cmdf=%~f0"
if exist "%SystemRoot%\Sysnative\cmd.exe" (
setlocal EnableDelayedExpansion
start %SystemRoot%\Sysnative\cmd.exe /c ""!_cmdf!" %*"
exit /b
)
set "SysPath=%Windir%\System32"
if exist "%Windir%\Sysnative\reg.exe" (set "SysPath=%Windir%\Sysnative")
set "Path=%SysPath%;%Windir%;%SysPath%\Wbem;%SysPath%\WindowsPowerShell\v1.0\"
reg query HKU\S-1-5-19 1>nul 2>nul && goto :PROMPT
echo Run as administrator
echo Press any key to exit.
pause >nul
exit /b

:PROMPT
IF NOT "%_MOUNT%"=="" IF EXIST "%_MOUNT%\Windows\System32\kernel32.dll" GOTO :PROMP2
@CLS
SET _MOUNT=
ECHO ============================================================
ECHO Enter Mount Directory Path
ECHO ============================================================
ECHO.
SET /P _MOUNT=
IF NOT DEFINED _MOUNT GOTO :EOF
IF NOT EXIST "%_MOUNT%\Windows\System32\kernel32.dll" goto :PROMPT
ECHO.

:PROMP2
IF NOT "%_File%"=="" GOTO :BEGIN
SET _File=
ECHO ============================================================
ECHO Enter a File Name to Check
ECHO ============================================================
ECHO.
SET /P _File=
IF NOT DEFINED _File GOTO :EOF

:BEGIN
@CLS
:: @MODE 105, 3000
SET "_KeyComponents=HKLM\OCOMPONENTS\DerivedData\Components"
SET "_KeyDeployments=HKLM\OCOMPONENTS\CanonicalData\Deployments"
REG QUERY HKLM\OCOMPONENTS 1>NUL 2>NUL || (
ECHO ============================================================
ECHO Loading COMPONENTS hive
ECHO ============================================================
ECHO.
SET _UNLOAD=1
REG LOAD HKLM\OCOMPONENTS "%_MOUNT%\Windows\System32\Config\COMPONENTS" >NUL
)

ECHO ============================================================
ECHO.
ECHO Resolving: %_File%

:: DIR /B /S /A:-D "%_MOUNT%\Windows\WinSxS\%_File%" 1>NUL 2>NUL || (ECHO.&ECHO Error: File is not detected in WinSxS store.&GOTO :END)

IF EXIST "%_MOUNT%\Windows\SysWOW64\*.dll" (SET _Arch=amd64) ELSE (SET _Arch=x86)

FOR /F "TOKENS=7,8 DELIMS=\_" %%A IN ('REG QUERY "%_KeyComponents%" /v "f!%_File%" /s 2^>NUL ^| FINDSTR /I "DerivedData"') DO IF NOT DEFINED %%A_%%B (SET "%%A_%%B=1"&SET "_Assembly=%%A_%%B"&CALL :ASSEMBLIES)

GOTO :END

:ASSEMBLIES
FOR /F "TOKENS=5 DELIMS=\" %%A IN ('REG QUERY "%_KeyComponents%" /f "%_Assembly%_" /k 2^>NUL ^| FINDSTR /I "DerivedData" ^| FINDSTR /I /V ".resources_"') DO (SET "_Component=%%A"&CALL :COMPONENTS)
EXIT /B

:COMPONENTS
REG QUERY "%_KeyComponents%\%_Component%" 2>NUL | FINDSTR /I "c!" 1>NUL || (EXIT /B)
REG QUERY "%_KeyComponents%\%_Component%" /v "f!%_File%" 1>NUL 2>NUL && (SET _STATUS=*) || (SET _STATUS=-)
FOR /F "TOKENS=2 DELIMS=! " %%A IN ('REG QUERY "%_KeyComponents%\%_Component%" 2^>NUL ^| FINDSTR /I "c!"') DO (SET "_Deployment=%%A"&CALL :DEPLOYMENTS)
EXIT /B

:DEPLOYMENTS
REG QUERY "%_KeyDeployments%\%_Deployment%" 2>NUL | FINDSTR /I "p!" 1>NUL || (EXIT /B)
ECHO ____________________________________________________________
ECHO.
ECHO Component [%_STATUS%]:
ECHO %_Component%
ECHO.
ECHO Deployment:
FOR /F %%A IN ('DIR /B /A:-D "%_MOUNT%\Windows\WinSxS\Manifests\*%_Deployment:~-16%*" 2^>NUL') DO IF NOT ERRORLEVEL 1 ECHO %%~nA
ECHO.
ECHO Package:
FOR /F "TOKENS=2 DELIMS=!~ " %%A IN ('REG QUERY "%_KeyDeployments%\%_Deployment%" 2^>NUL ^| FINDSTR /I "p!"') DO (SET "_Package=%%A"&CALL :PACKAGES)
EXIT /B

:PACKAGES
:: FOR /F %%A IN ('DIR /B "%_MOUNT%\Windows\servicing\Packages\*%_Package:~4%~*~~*.mum" 2^>NUL ^| FINDSTR /I /V "WOW64"') DO IF NOT ERRORLEVEL 1 ECHO %%~nA
FOR /F %%A IN ('DIR /B "%_MOUNT%\Windows\servicing\Packages\*%_Package:~4%~*~~*.mum" 2^>NUL') DO IF NOT ERRORLEVEL 1 ECHO %%~nA
EXIT /B

:END
IF DEFINED _UNLOAD REG UNLOAD HKLM\OCOMPONENTS >NUL
ECHO.
ECHO ============================================================
ECHO.
ECHO Press any key to exit . . .
PAUSE >NUL
EXIT /B
