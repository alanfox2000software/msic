@setlocal DisableDelayedExpansion
@echo off

SET "_File=kernel32.dll"
SET "_File="

set "_cmdf=%~f0"
if exist "%SystemRoot%\Sysnative\cmd.exe" (
setlocal EnableDelayedExpansion
start %SystemRoot%\Sysnative\cmd.exe /c ""!_cmdf!" %*"
exit /b
)
set "SysPath=%Windir%\System32"
if exist "%Windir%\Sysnative\reg.exe" (set "SysPath=%Windir%\Sysnative")
set "Path=%SysPath%;%Windir%;%SysPath%\Wbem;%SysPath%\WindowsPowerShell\v1.0\"
reg query HKU\S-1-5-19 1>nul 2>nul && goto :PROMPT
echo Run as administrator
echo Press any key to exit.
pause >nul
exit /b

:PROMPT
IF NOT "%_File%"=="" GOTO :BEGIN
SET _File=
ECHO ============================================================
ECHO Enter a File Name to Check
ECHO ============================================================
ECHO.
SET /P _File=
IF NOT DEFINED _File GOTO :EOF

:BEGIN
@CLS
:: @MODE 105, 3000
SET "_KeyComponents=HKLM\COMPONENTS\DerivedData\Components"
SET "_KeyDeployments=HKLM\COMPONENTS\CanonicalData\Deployments"
REG QUERY HKLM\COMPONENTS 1>NUL 2>NUL || (
ECHO ============================================================
ECHO Loading COMPONENTS hive
ECHO ============================================================
ECHO.
SET _UNLOAD=1
REG LOAD HKLM\COMPONENTS %SystemRoot%\System32\Config\COMPONENTS >NUL
)

ECHO ============================================================
ECHO.
ECHO Resolving: %_File%

:: DIR /B /S /A:-D "%SystemRoot%\WinSxS\%_File%" 1>NUL 2>NUL || (ECHO.&ECHO Error: File is not detected in WinSxS store.&GOTO :END)

FOR /F "TOKENS=7,8 DELIMS=\_" %%A IN ('REG QUERY "%_KeyComponents%" /v "f!%_File%" /s 2^>NUL ^| FINDSTR /I "DerivedData"') DO (
IF /I "%%A"=="msil" (SET "_Assembly=%%A_%%B") ELSE (SET "_Assembly=%PROCESSOR_ARCHITECTURE%_%%B")
)
FOR /F "TOKENS=5 DELIMS=\" %%A IN ('REG QUERY "%_KeyComponents%" /f "%_Assembly%_" /k 2^>NUL ^| FINDSTR /I "DerivedData" ^| FINDSTR /I /V ".resources_"') DO (SET "_Component=%%A"&CALL :COMPONENTS)

GOTO :END

:COMPONENTS
REG QUERY "%_KeyComponents%\%_Component%" 2>NUL | FINDSTR /I "c!" 1>NUL || (EXIT /B)
REG QUERY "%_KeyComponents%\%_Component%" /v "f!%_File%" 1>NUL 2>NUL && (SET _STATUS=*) || (SET _STATUS=-)
FOR /F "TOKENS=2 DELIMS=! " %%A IN ('REG QUERY "%_KeyComponents%\%_Component%" 2^>NUL ^| FINDSTR /I "c!"') DO (SET "_Deployment=%%A"&CALL :DEPLOYMENTS)
EXIT /B

:DEPLOYMENTS
REG QUERY "%_KeyDeployments%\%_Deployment%" 2>NUL | FINDSTR /I "p!" 1>NUL || (EXIT /B)
ECHO ____________________________________________________________
ECHO.
ECHO Component [%_STATUS%]:
ECHO %_Component%
ECHO.
ECHO Deployment:
FOR /F %%A IN ('DIR /B /A:-D "%SystemRoot%\WinSxS\Manifests\*%_Deployment:~-16%*" 2^>NUL') DO IF NOT ERRORLEVEL 1 ECHO %%~nA
ECHO.
ECHO Package:
FOR /F "TOKENS=2 DELIMS=!~ " %%A IN ('REG QUERY "%_KeyDeployments%\%_Deployment%" 2^>NUL ^| FINDSTR /I "p!"') DO (SET "_Package=%%A"&CALL :PACKAGES)
EXIT /B

:PACKAGES
FOR /F %%A IN ('DIR /B "%SystemRoot%\servicing\Packages\*%_Package:~4%~*~~*.mum" 2^>NUL ^| FINDSTR /I /V "WOW64"') DO IF NOT ERRORLEVEL 1 ECHO %%~nA
EXIT /B

:END
IF DEFINED _UNLOAD REG UNLOAD HKLM\COMPONENTS >NUL
ECHO.
ECHO ============================================================
ECHO.
ECHO Press any key to exit . . .
PAUSE >NUL
EXIT /B
